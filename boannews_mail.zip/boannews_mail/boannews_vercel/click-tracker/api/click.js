// 리포트/알림 링크 클릭을 기록하고 원본 URL로 리다이렉트한다.
//
// boannews_mail 프로젝트(scripts/common_utils.py의 tracking_url())가 기사 링크를
// 이 엔드포인트(/api/click?ref=<10자리 해시>&url=<원본 URL>) 경유로 바꿔서 내보내고,
// scripts/click_feedback_puller.py가 여기 쌓인 클릭 로그를 Redis에서 읽어가
// useful 피드백 라벨로 변환한다.
//
// 필요 환경변수(Vercel 프로젝트 설정 > Environment Variables, Storage 연결 시 자동 생성):
//   REDIS_URL — redis://... 형식의 네이티브 Redis 연결 문자열
// 없으면 로깅만 건너뛰고 리다이렉트는 그대로 동작한다.
//
// IP별 요청 제한(RATE_LIMIT)과 리스트 길이 상한(MAX_LIST_SIZE)은 lib/redisGuards.js —
// 둘 다 리다이렉트 자체는 막지 않고 로깅만 건너뛰게 한다(추적 실패가 열람을 막으면 안 됨).

const Redis = require("ioredis");
const { isRateLimited, capList, getClientIp } = require("../lib/redisGuards");

// IP당 이 창(초) 안에 이 횟수 넘게 오면 그 요청은 로깅만 스킵한다(리다이렉트는 항상 함).
const RATE_LIMIT = 60;
const RATE_WINDOW_SECONDS = 60;
const MAX_LIST_SIZE = 5000; // 풀러가 한동안 안 돌아도 Redis에 무한정 쌓이지 않게 하는 상한

// 서버리스 함수가 재사용(warm start)될 때 연결을 재활용 — 매 요청마다 새로 연결하지 않는다.
let redisClient = null;
function getRedisClient() {
  if (!process.env.REDIS_URL) return null;
  if (!redisClient) {
    redisClient = new Redis(process.env.REDIS_URL, {
      maxRetriesPerRequest: 1,
      connectTimeout: 3000,
    });
    redisClient.on("error", (error) => console.error("redis client error", error));
  }
  return redisClient;
}

// 사람이 실제로 열어보기 전에 링크를 자동으로 미리 가져가는 주체들 — 이메일 보안
// 스캐너(Safe Links류), 채팅 앱의 링크 미리보기 봇, 범용 크롤러. 이런 요청까지
// "클릭"으로 세면 아무도 안 읽은 기사에 useful 라벨이 자동으로 붙어버린다.
// 리다이렉트 자체는 이 요청들에도 그대로 해준다 — 로깅만 건너뛴다.
const PREFETCH_UA_PATTERNS = [
  /slackbot/i, /slack-imgproxy/i,
  /bot|crawler|spider|preview|unfurl/i,
  /facebookexternalhit/i, /twitterbot/i, /linkedinbot/i, /whatsapp/i, /telegrambot/i, /discordbot/i,
  /googlebot|bingbot/i,
  /safelinks|safe-links|atp-scanner|proofpoint|mimecast|barracuda/i,
];

function isPrefetchRequest(userAgent) {
  if (!userAgent) return true; // UA 없는 요청도 사람의 일반 브라우저는 아닐 가능성이 높음
  return PREFETCH_UA_PATTERNS.some((pattern) => pattern.test(userAgent));
}

module.exports = async (req, res) => {
  const { ref, url } = req.query;

  if (!url || typeof url !== "string") {
    res.status(400).send("Missing url parameter");
    return;
  }

  let target;
  try {
    target = decodeURIComponent(url);
    // eslint-disable-next-line no-new
    new URL(target); // 유효한 절대 URL인지 검증 — 아니면 오픈 리다이렉트 악용 방지 위해 거부
  } catch (error) {
    res.status(400).send("Invalid url parameter");
    return;
  }

  const client = getRedisClient();
  if (client && ref && !isPrefetchRequest(req.headers["user-agent"])) {
    const limited = await isRateLimited(client, "click", getClientIp(req), RATE_LIMIT, RATE_WINDOW_SECONDS);
    if (!limited) {
      const record = JSON.stringify({ ref: String(ref), url: target, ts: new Date().toISOString() });
      try {
        await client.rpush("clicks", record);
        await capList(client, "clicks", MAX_LIST_SIZE);
      } catch (error) {
        // 로그 실패해도 사용자 리다이렉트는 반드시 진행 — 추적 실패가 열람을 막으면 안 됨
        console.error("click log failed", error);
      }
    }
  }

  res.writeHead(302, { Location: target });
  res.end();
};
